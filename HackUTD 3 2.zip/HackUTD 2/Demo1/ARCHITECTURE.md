# NemoCode.io - System Architecture & Flowchart

## 🏗️ High-Level Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER INTERFACE                           │
│          (HTML/CSS/JavaScript + Tailwind CSS)                   │
│                                                                  │
│  Input Form → Loading State → Results Display (Tabs)            │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      │ HTTP POST /api/plan-trip
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                      FLASK BACKEND API                           │
│                        (Port 5001)                               │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      │ Triggers Agent Workflow
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                   AGENT ORCHESTRATOR                             │
│                    (workflow.py)                                 │
│                                                                  │
│  ┌────────────┐    ┌────────────┐    ┌─────────────┐          │
│  │  PLANNER   │───▶│  EXECUTOR  │───▶│ SYNTHESIZER │          │
│  └────────────┘    └────────────┘    └─────────────┘          │
│       ▲                  ▲                   ▲                   │
│       │                  │                   │                   │
│       └──────────────────┴───────────────────┘                  │
│              NVIDIA NEMOTRON LLM                                 │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      │ Calls External APIs & Tools
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                     TOOL LAYER (tools/)                          │
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌────────┐  ┌─────────┐          │
│  │  Maps    │  │ Weather  │  │ Places │  │ Hotels  │          │
│  └──────────┘  └──────────┘  └────────┘  └─────────┘          │
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌────────────┐                   │
│  │ Clothing │  │  Music   │  │  History   │                   │
│  └──────────┘  └──────────┘  └────────────┘                   │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      │ External API Calls
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL SERVICES                             │
│                                                                  │
│  • Google Maps API          • Weather API                       │
│  • Google Places API        • NVIDIA Nemotron API               │
│  • Google Gemini API        • Mock Data (fallback)              │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Detailed Agent Workflow Flowchart

```
                    ┌─────────────────────┐
                    │   USER SUBMITS      │
                    │    TRIP REQUEST     │
                    │                     │
                    │ • Origin            │
                    │ • Destination       │
                    │ • Budget            │
                    │ • Dates             │
                    │ • Interests         │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │   AGENT STATE       │
                    │   INITIALIZATION    │
                    │                     │
                    │ • Set budget        │
                    │ • Parse dates       │
                    │ • Extract params    │
                    └──────────┬──────────┘
                               │
                               ▼
        ╔═══════════════════════════════════════════════╗
        ║           STEP 1: PLANNER AGENT               ║
        ║         (Powered by Nemotron LLM)             ║
        ╚═══════════════════════════════════════════════╝
                               │
                    ┌──────────▼──────────┐
                    │  Analyze Request    │
                    │  & Create Plan      │
                    │                     │
                    │ Input: User request │
                    │ Output: Step list   │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  PLAN GENERATED:    │
                    │  1. Calculate costs │
                    │  2. Find transport  │
                    │  3. Find hotel      │
                    │  4. Check weather   │
                    │  5. Search POIs     │
                    │  6. Get history     │
                    │  7. Create itinerary│
                    └──────────┬──────────┘
                               │
                               ▼
        ╔═══════════════════════════════════════════════╗
        ║          STEP 2: EXECUTOR AGENT               ║
        ║         (Multi-Step Execution)                ║
        ╚═══════════════════════════════════════════════╝
                               │
                               ▼
        ┌──────────────────────────────────────┐
        │  Execute Each Step Sequentially:     │
        └──────────────────────────────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
            ▼                  ▼                  ▼
    ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
    │ Step 1:      │   │ Step 2:      │   │ Step 3:      │
    │ Calculate    │   │ Find         │   │ Search       │
    │ Transport    │   │ Hotels       │   │ Hotels       │
    │              │   │              │   │              │
    │ Tool: maps   │   │ Tool: maps   │   │ Tool: hotels │
    └──────┬───────┘   └──────┬───────┘   └──────┬───────┘
           │                  │                  │
           └──────────────────┴──────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  Update Agent State │
                    │  • Transport cost   │
                    │  • Hotel selection  │
                    │  • Budget remaining │
                    └──────────┬──────────┘
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
            ▼                  ▼                  ▼
    ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
    │ Step 4:      │   │ Step 5:      │   │ Step 6:      │
    │ Check        │   │ Search       │   │ Select       │
    │ Weather      │   │ Activities   │   │ Activities   │
    │              │   │              │   │              │
    │ Tool: weather│   │ Tool: places │   │ Budget-aware │
    └──────┬───────┘   └──────┬───────┘   └──────┬───────┘
           │                  │                  │
           └──────────────────┴──────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  Final State:       │
                    │  • Transport ✓      │
                    │  • Hotels ✓         │
                    │  • Activities ✓     │
                    │  • Weather data ✓   │
                    └──────────┬──────────┘
                               │
                               ▼
        ╔═══════════════════════════════════════════════╗
        ║         STEP 3: SYNTHESIZER AGENT             ║
        ║       (Creates Final Itinerary)               ║
        ╚═══════════════════════════════════════════════╝
                               │
                               ▼
        ┌──────────────────────────────────────┐
        │  Generate All Components:            │
        └──────────────────────────────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
            ▼                  ▼                  ▼
    ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
    │ Daily        │   │ Budget       │   │ Map Points   │
    │ Schedule     │   │ Breakdown    │   │              │
    │              │   │              │   │ Lat/Lng      │
    │ Day by day   │   │ Transport    │   │ Markers      │
    │ Time slots   │   │ Lodging      │   │              │
    └──────────────┘   │ Activities   │   └──────────────┘
                       └──────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
            ▼                  ▼                  ▼
    ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
    │ Clothing     │   │ Music        │   │ City History │
    │ Suggestions  │   │ Playlist     │   │              │
    │              │   │              │   │ Gemini API   │
    │ Tool:        │   │ Tool:        │   │ Tool:        │
    │ clothing     │   │ music        │   │ history      │
    │              │   │              │   │              │
    │ • Nemotron   │   │ • Nemotron   │   │ • Gemini     │
    │ • Weather    │   │ • Location   │   │ • Historical │
    │ • Season     │   │ • Genre      │   │   context    │
    │ • Climate    │   │ • Mood       │   │              │
    └──────┬───────┘   └──────┬───────┘   └──────┬───────┘
           │                  │                  │
           └──────────────────┴──────────────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  COMPLETE ITINERARY │
                    │   (Pydantic Model)  │
                    │                     │
                    │ • items: []         │
                    │ • budget: {}        │
                    │ • map_points: []    │
                    │ • clothing: {}      │
                    │ • music: {}         │
                    │ • history: {}       │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  JSON SERIALIZATION │
                    │    (Flask Backend)  │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │   HTTP RESPONSE     │
                    │   (200 OK + JSON)   │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │  FRONTEND DISPLAYS  │
                    │  RESULTS IN TABS    │
                    │                     │
                    │ 📅 Schedule         │
                    │ 💰 Budget           │
                    │ 🗺️  Map             │
                    │ 👔 Clothing         │
                    │ 🎵 Music            │
                    │ 📚 History          │
                    └─────────────────────┘
```

---

## 🎨 Component Interaction Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND LAYER                            │
│                                                                  │
│  ┌──────────────┐         ┌──────────────┐                     │
│  │ Input Form   │────────▶│ Results View │                     │
│  │              │         │              │                     │
│  │ • Origin     │         │ • Schedule   │                     │
│  │ • Destination│         │ • Budget     │                     │
│  │ • Budget     │         │ • Map        │                     │
│  │ • Dates      │         │ • Clothing   │                     │
│  │ • Interests  │         │ • Music      │                     │
│  └──────┬───────┘         │ • History    │                     │
│         │                 └──────▲───────┘                     │
│         │                        │                              │
└─────────┼────────────────────────┼──────────────────────────────┘
          │                        │
          │ POST /api/plan-trip    │ JSON Response
          │                        │
┌─────────▼────────────────────────┴──────────────────────────────┐
│                       BACKEND LAYER                              │
│                                                                  │
│  ┌──────────────────────────────────────────────────┐          │
│  │            Flask REST API (app.py)               │          │
│  │                                                   │          │
│  │  • Receive request                               │          │
│  │  • Parse parameters                              │          │
│  │  • Call agent workflow                           │          │
│  │  • Serialize response                            │          │
│  └─────────────────────┬────────────────────────────┘          │
│                        │                                         │
│  ┌─────────────────────▼────────────────────────────┐          │
│  │          Agent Orchestrator (workflow.py)        │          │
│  │                                                   │          │
│  │  ┌─────────┐   ┌──────────┐   ┌──────────────┐  │          │
│  │  │ Planner │──▶│ Executor │──▶│ Synthesizer  │  │          │
│  │  └─────────┘   └──────────┘   └──────────────┘  │          │
│  └─────────────────────┬────────────────────────────┘          │
│                        │                                         │
│  ┌─────────────────────▼────────────────────────────┐          │
│  │              LLM Client (llm.py)                  │          │
│  │                                                   │          │
│  │  • NVIDIA Nemotron API                           │          │
│  │  • Prompt engineering                            │          │
│  │  • Response parsing                              │          │
│  └─────────────────────┬────────────────────────────┘          │
│                        │                                         │
└────────────────────────┼─────────────────────────────────────────┘
                         │
                         │ Calls tools & APIs
                         │
┌────────────────────────▼─────────────────────────────────────────┐
│                       TOOLS LAYER                                 │
│                                                                   │
│  ┌──────────┐  ┌──────────┐  ┌────────┐  ┌─────────┐           │
│  │  maps.py │  │weather.py│  │places.py│ │hotels.py│           │
│  │          │  │          │  │         │  │         │           │
│  │ • Geocode│  │ • Temp   │  │ • Search│  │ • Find  │           │
│  │ • Distance│ │ • Rain % │  │ • Filter│  │ • Rank  │           │
│  │ • Route  │  │ • Season │  │ • Rank  │  │ • Price │           │
│  └────┬─────┘  └────┬─────┘  └────┬────┘  └────┬────┘           │
│       │             │             │            │                 │
│  ┌────▼─────┐  ┌────▼──────┐  ┌──▼───────────▼──┐              │
│  │clothing.py│  │ music.py  │  │   history.py    │              │
│  │           │  │           │  │                 │              │
│  │ • Nemotron│  │ • Nemotron│  │ • Gemini API    │              │
│  │ • Weather │  │ • Location│  │ • Historical    │              │
│  │ • Season  │  │ • Genre   │  │   context       │              │
│  │ • Colors  │  │ • Songs   │  │ • Cultural info │              │
│  └───────────┘  └───────────┘  └─────────────────┘              │
│                                                                   │
└───────────────────────────┬───────────────────────────────────────┘
                            │
                            │ External API Calls
                            │
┌───────────────────────────▼───────────────────────────────────────┐
│                     EXTERNAL SERVICES                              │
│                                                                    │
│  ┌────────────────┐  ┌────────────────┐  ┌──────────────────┐   │
│  │ NVIDIA Nemotron│  │ Google Maps    │  │ Google Places    │   │
│  │      API       │  │      API       │  │       API        │   │
│  └────────────────┘  └────────────────┘  └──────────────────┘   │
│                                                                    │
│  ┌────────────────┐  ┌────────────────┐  ┌──────────────────┐   │
│  │ Google Gemini  │  │  Weather API   │  │   Mock Data      │   │
│  │      API       │  │                │  │   (Fallback)     │   │
│  └────────────────┘  └────────────────┘  └──────────────────┘   │
└────────────────────────────────────────────────────────────────────┘
```

---

## 🧠 NVIDIA Nemotron Integration Points

```
┌─────────────────────────────────────────────────────────────────┐
│               NVIDIA NEMOTRON LLM USAGE                          │
└─────────────────────────────────────────────────────────────────┘

1. PLANNER AGENT (agent/planner.py)
   ┌────────────────────────────────────────┐
   │ Input: User trip request              │
   │ Nemotron: Strategic reasoning         │
   │ Output: Step-by-step execution plan   │
   └────────────────────────────────────────┘
   Example Prompt:
   "Create a travel plan for Austin to NYC, $800 budget, 3 days.
    Break into logical steps considering transport, lodging, activities."

2. CLOTHING TOOL (tools/clothing.py)
   ┌────────────────────────────────────────┐
   │ Input: Destination, dates, weather    │
   │ Nemotron: Fashion & style reasoning   │
   │ Output: Outfits, colors, accessories  │
   └────────────────────────────────────────┘
   Example Prompt:
   "Suggest trendy outfits for NYC in November (40-50°F, 60% rain).
    Provide color palettes and outfit items for male/female."

3. MUSIC TOOL (tools/music.py)
   ┌────────────────────────────────────────┐
   │ Input: Destination, season, vibe      │
   │ Nemotron: Cultural & music reasoning  │
   │ Output: Songs, genres, mood           │
   └────────────────────────────────────────┘
   Example Prompt:
   "Recommend 7 songs for social media posts in NYC.
    Consider local culture, vibe, and popular genres."

4. CITY HISTORY (via Gemini - not Nemotron)
   ┌────────────────────────────────────────┐
   │ Input: Destination city               │
   │ Gemini: Historical knowledge          │
   │ Output: Brief history overview        │
   └────────────────────────────────────────┘
```

---

## 📊 Data Flow Diagram

```
USER INPUT                 PROCESSING                  OUTPUT
─────────                  ──────────                 ──────

Origin: Austin      ──▶    Agent State Init    ──▶    Transport: $600
Destination: NYC    ──▶    Budget: $800              Flight selected
Budget: $800        ──▶    Dates: 3 days             
Dates: 2025-11-15   ──▶                              
Interests: Parks    ──▶    ┌──────────┐              Hotels: $206
                           │ PLANNER  │              The Jane Hotel
                           └────┬─────┘              
                                │                     
                           ┌────▼─────┐              Activities: $0
                           │ EXECUTOR │              Central Park (free)
                           │          │              Brooklyn Bridge (free)
                           │ Tools:   │              
                           │ • maps   │              Weather: 45°F
                           │ • hotels │              60% rain chance
                           │ • places │              
                           │ • weather│              Clothing:
                           └────┬─────┘              • Warm jacket
                                │                    • Rain boots
                           ┌────▼──────┐             • Colors: Navy, Gray
                           │SYNTHESIZER│             
                           └────┬──────┘             Music:
                                │                    • "Empire State"
                                │                    • "NYC" by Interpol
                           ┌────▼──────┐             
                           │  OUTPUT   │             History:
                           │  (JSON)   │             "NYC founded 1624..."
                           └───────────┘             
```

---

## 🎯 Key Architecture Highlights for Presentation

### 1. **Agent-Based Design** 🤖
- **Planner**: Strategic reasoning (what to do)
- **Executor**: Tactical execution (how to do it)
- **Synthesizer**: Result compilation (final output)

### 2. **NVIDIA Nemotron Integration** ⚡
- Powers all intelligent decision-making
- Natural language understanding
- Context-aware reasoning

### 3. **Modular Tool System** 🔧
- Each tool is independent and reusable
- Easy to add new tools (flights, restaurants, etc.)
- Fallback mechanisms for robustness

### 4. **Full-Stack Architecture** 🌐
- Flask backend (REST API)
- JavaScript frontend (async/await)
- Real-time API integrations

### 5. **Data Validation** ✅
- Pydantic models throughout
- Type-safe data structures
- JSON serialization/deserialization

---

## 📈 Performance & Scalability

```
Current Architecture:
┌─────────────┐
│   1 User    │
│   Request   │
└──────┬──────┘
       │
       ▼
┌─────────────┐     ┌──────────────┐
│   Flask     │────▶│  Nemotron    │
│   Backend   │     │    API       │
└─────────────┘     └──────────────┘
       │
       ▼
┌─────────────┐
│   Response  │
└─────────────┘

Scalable Architecture (Future):
┌─────────────┐
│  Multiple   │
│   Users     │
└──────┬──────┘
       │
       ▼
┌─────────────┐     ┌──────────────┐
│ Load        │     │   Redis      │
│ Balancer    │────▶│   Cache      │
└──────┬──────┘     └──────────────┘
       │
       ▼
┌─────────────┐     ┌──────────────┐
│  Multiple   │────▶│  Nemotron    │
│  Flask      │     │   API Pool   │
│  Instances  │     └──────────────┘
└─────────────┘
       │
       ▼
┌─────────────┐
│  Database   │
│  (User data)│
└─────────────┘
```

---

## 💡 Tips for Presenting This Architecture

1. **Start High-Level**: Show the 3-layer diagram (Frontend → Backend → APIs)
2. **Zoom into Agent Flow**: Explain Planner → Executor → Synthesizer
3. **Highlight Nemotron**: Point out where AI makes decisions
4. **Show Data Flow**: Trace one request through the entire system
5. **Emphasize Modularity**: Explain how easy it is to add features

---

## 🖼️ Visual Recommendations

For your presentation slides, consider creating:

1. **Simple flowchart** (User → Agent → APIs → Output)
2. **Agent detail diagram** (Planner/Executor/Synthesizer)
3. **Nemotron integration points** (highlight AI usage)
4. **Before/After comparison** (10 apps vs 1 NemoCode.io)

Tools to create visuals:
- **Figma** (free, professional)
- **Excalidraw** (free, hand-drawn style)
- **Lucidchart** (free tier available)
- **Draw.io** (free, powerful)
- **Miro** (free, collaborative)

---

**This architecture showcases your technical depth and system thinking! 🚀**


