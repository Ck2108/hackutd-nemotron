"""
Flask backend API for Nemotron Itinerary Agent
"""
import os
import sys
import json
import logging
from datetime import date, datetime
from pathlib import Path
from flask import Flask, request, jsonify
from flask_cors import CORS
from typing import Dict, Any

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import agent modules
from agent.state import UserRequest
from agent.planner import create_plan
from agent.executor import execute_plan, select_activities
from agent.synthesizer import create_itinerary, generate_calendar_events

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({"status": "healthy", "message": "Nemotron Itinerary Agent API is running"})


@app.route('/api/plan-trip', methods=['POST'])
def plan_trip():
    """Plan a trip based on user request."""
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['origin', 'destination', 'start_date', 'end_date', 'travelers', 'budget_total']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        # Parse dates
        start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
        end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
        
        # Validate dates
        if start_date >= end_date:
            return jsonify({"error": "End date must be after start date"}), 400
        
        # Create user request
        user_request = UserRequest(
            origin=data['origin'],
            destination=data['destination'],
            start_date=start_date,
            end_date=end_date,
            travelers=data['travelers'],
            budget_total=float(data['budget_total']),
            interests=data.get('interests', [])
        )
        
        # Set environment variables
        use_mocks = data.get('use_mocks', False)
        weather_mode = data.get('weather_mode', 'sunny')
        os.environ["USE_MOCKS"] = str(use_mocks).lower()
        os.environ["WEATHER_DEMO_MODE"] = weather_mode
        
        # Run the agent workflow
        logger.info(f"Planning trip: {user_request.origin} -> {user_request.destination}")
        
        # Step 1: Planning
        agent_state = create_plan(user_request)
        
        # Step 2: Execution
        agent_state = execute_plan(agent_state)
        
        # Step 3: Activity Selection
        agent_state = select_activities(
            agent_state, 
            user_request.interests, 
            destination_city=user_request.destination
        )
        
        # Step 4: Synthesis
        itinerary = create_itinerary(agent_state, user_request)
        
        # Convert to JSON-serializable format
        result = {
            "user_request": {
                "origin": user_request.origin,
                "destination": user_request.destination,
                "start_date": user_request.start_date.isoformat(),
                "end_date": user_request.end_date.isoformat(),
                "travelers": user_request.travelers,
                "budget_total": user_request.budget_total,
                "interests": user_request.interests
            },
            "agent_state": _serialize_agent_state(agent_state),
            "itinerary": _serialize_itinerary(itinerary)
        }
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error planning trip: {str(e)}", exc_info=True)
        return jsonify({"error": str(e), "type": type(e).__name__}), 500


@app.route('/api/download-calendar', methods=['POST'])
def download_calendar():
    """Generate calendar events for download."""
    try:
        data = request.json
        itinerary_dict = data.get('itinerary')
        
        # Reconstruct itinerary from dict (simplified)
        from agent.state import Itinerary
        # This would require full deserialization - for now, return the data
        # In production, you'd want proper deserialization
        
        return jsonify({"error": "Calendar download not yet implemented in API"}), 501
        
    except Exception as e:
        logger.error(f"Error generating calendar: {str(e)}")
        return jsonify({"error": str(e)}), 500


def _serialize_agent_state(agent_state) -> Dict[str, Any]:
    """Serialize agent state to JSON-serializable dict."""
    result = {
        "plan": [
            {
                "tool": step.tool,
                "params": step.params,
                "description": step.description,
                "phase": step.phase
            }
            for step in agent_state.plan
        ],
        "log": [
            {
                "tool": result.tool,
                "input": result.input,
                "output": result.output,
                "cost_estimate": result.cost_estimate,
                "notes": result.notes,
                "thinking": result.thinking
            }
            for result in agent_state.log
        ],
        "budget_remaining": agent_state.budget_remaining
    }
    
    # Serialize selections if they exist
    if hasattr(agent_state, 'selections') and agent_state.selections:
        selections = agent_state.selections
        result["transport"] = _serialize_transport(selections.transport) if hasattr(selections, 'transport') and selections.transport else None
        result["hotel"] = _serialize_hotel(selections.hotel) if hasattr(selections, 'hotel') and selections.hotel else None
        result["activities"] = [
            _serialize_activity(activity) for activity in selections.activities
        ] if hasattr(selections, 'activities') and selections.activities else []
    else:
        # Fallback: try direct attributes (for backward compatibility)
        result["transport"] = _serialize_transport(getattr(agent_state, 'transport', None)) if getattr(agent_state, 'transport', None) else None
        result["hotel"] = _serialize_hotel(getattr(agent_state, 'hotel', None)) if getattr(agent_state, 'hotel', None) else None
        result["activities"] = [
            _serialize_activity(activity) for activity in getattr(agent_state, 'activities', [])
        ] if getattr(agent_state, 'activities', None) else []
    
    return result


def _serialize_transport(transport) -> Dict[str, Any]:
    """Serialize transport selection."""
    if not transport:
        return None
    return {
        "mode": transport.mode,
        "duration_minutes": getattr(transport, 'duration_minutes', getattr(transport, 'duration', 0)),
        "distance_miles": getattr(transport, 'distance_miles', getattr(transport, 'distance', 0.0)),
        "cost": transport.cost,
        "details": getattr(transport, 'details', {})
    }


def _serialize_hotel(hotel) -> Dict[str, Any]:
    """Serialize hotel selection."""
    if not hotel:
        return None
    return {
        "name": hotel.name,
        "address": getattr(hotel, 'address', None),
        "price_per_night": hotel.price_per_night,
        "total_price": hotel.total_price,  # Fixed: was total_cost
        "total_cost": hotel.total_price,  # Also include as total_cost for compatibility
        "rating": hotel.rating,
        "link": getattr(hotel, 'link', None),
        "latitude": hotel.lat,  # Fixed: was latitude
        "longitude": hotel.lng,  # Fixed: was longitude
        "lat": hotel.lat,  # Include both for compatibility
        "lng": hotel.lng
    }


def _serialize_activity(activity) -> Dict[str, Any]:
    """Serialize activity selection."""
    if not activity:
        return None
    return {
        "name": activity.name,
        "type": activity.tags[0] if activity.tags else "activity",  # Use first tag as type
        "tags": activity.tags,  # Include all tags
        "address": getattr(activity, 'address', None),
        "cost": activity.price,  # Fixed: was cost
        "price": activity.price,  # Include both for compatibility
        "rating": activity.rating,
        "link": getattr(activity, 'link', None),
        "place_id": getattr(activity, 'place_id', None),
        "latitude": activity.lat,  # Fixed: was latitude
        "longitude": activity.lng,  # Fixed: was longitude
        "lat": activity.lat,  # Include both for compatibility
        "lng": activity.lng,
        "matched_interests": activity.tags  # Use tags as matched interests
    }


def _serialize_itinerary(itinerary) -> Dict[str, Any]:
    """Serialize itinerary to JSON-serializable dict."""
    # Use model_dump() for Pydantic v2, fallback to dict() for v1
    if hasattr(itinerary, 'model_dump'):
        try:
            itinerary_dict = itinerary.model_dump(mode='json')
        except Exception:
            # Fallback to regular dict if mode='json' fails
            itinerary_dict = itinerary.model_dump()
    else:
        itinerary_dict = itinerary.dict()
    
    # Convert date objects to strings and handle None values
    def convert_dates(obj):
        if obj is None:
            return None
        elif isinstance(obj, dict):
            return {k: convert_dates(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_dates(item) for item in obj]
        elif isinstance(obj, date):
            return obj.isoformat()
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif hasattr(obj, '__dict__'):  # Handle Pydantic models that weren't converted
            try:
                if hasattr(obj, 'model_dump'):
                    return convert_dates(obj.model_dump())
                elif hasattr(obj, 'dict'):
                    return convert_dates(obj.dict())
            except:
                return str(obj)
        else:
            return obj
    
    return convert_dates(itinerary_dict)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5001))  # Changed to 5001 to avoid AirPlay Receiver conflict
    app.run(debug=True, host='0.0.0.0', port=port)

