# NemoCode.io - Simple Architecture Diagram
## For Hackathon Slides

---

## 🎯 ONE-SLIDE ARCHITECTURE (Use This!)

```
┌───────────────────────────────────────────────────────────────────┐
│                         👤 USER                                    │
│                    "Plan my NYC trip"                              │
└─────────────────────────────┬─────────────────────────────────────┘
                              │
                              ▼
┌───────────────────────────────────────────────────────────────────┐
│                     🌐 WEB INTERFACE                               │
│              (HTML/CSS/JavaScript + Tailwind)                      │
└─────────────────────────────┬─────────────────────────────────────┘
                              │
                              ▼
┌───────────────────────────────────────────────────────────────────┐
│                     ⚙️ FLASK BACKEND API                           │
└─────────────────────────────┬─────────────────────────────────────┘
                              │
                              ▼
╔═══════════════════════════════════════════════════════════════════╗
║               🤖 NVIDIA NEMOTRON AI AGENT                          ║
║                                                                    ║
║    ┌─────────┐        ┌──────────┐       ┌──────────────┐       ║
║    │PLANNER  │───────▶│ EXECUTOR │──────▶│ SYNTHESIZER  │       ║
║    │  "What" │        │   "How"  │       │   "Output"   │       ║
║    └─────────┘        └──────────┘       └──────────────┘       ║
║                                                                    ║
╚═════════════════════════════╦═════════════════════════════════════╝
                              │
              ┌───────────────┼───────────────┐
              │               │               │
              ▼               ▼               ▼
    ┌─────────────────┐ ┌──────────┐ ┌────────────────┐
    │ 🗺️ Google Maps  │ │ 🌤️ Weather│ │ 🏨 Hotels/POIs │
    └─────────────────┘ └──────────┘ └────────────────┘
              │               │               │
              └───────────────┼───────────────┘
                              │
                              ▼
┌───────────────────────────────────────────────────────────────────┐
│                    📊 COMPLETE ITINERARY                           │
│                                                                    │
│  📅 Schedule  💰 Budget  🗺️ Map  👔 Clothing  🎵 Music  📚 History│
└───────────────────────────────────────────────────────────────────┘
```

---

## 🔥 THREE-STEP FLOW (Super Simple)

```
    STEP 1                  STEP 2                  STEP 3
    ──────                  ──────                  ──────

┌──────────┐            ┌──────────┐            ┌──────────┐
│   USER   │            │ NEMOTRON │            │  OUTPUT  │
│  INPUT   │     ──▶    │   AI     │    ──▶     │ RESULTS  │
│          │            │  AGENT   │            │          │
└──────────┘            └──────────┘            └──────────┘

 • Origin              • Plan steps           • Schedule
 • Destination         • Execute tasks        • Budget
 • Budget              • Call APIs            • Map
 • Dates               • Make decisions       • Clothing
 • Interests           • Synthesize           • Music
                                               • History
```

---

## 🧠 AGENT INTELLIGENCE (Detailed)

```
                        NVIDIA NEMOTRON
                              │
              ┌───────────────┼───────────────┐
              │               │               │
              ▼               ▼               ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │   PLANNER    │  │   EXECUTOR   │  │ SYNTHESIZER  │
    │              │  │              │  │              │
    │ • Analyze    │  │ • Find       │  │ • Compile    │
    │   request    │  │   transport  │  │   schedule   │
    │              │  │              │  │              │
    │ • Break down │  │ • Book       │  │ • Calculate  │
    │   into steps │  │   hotels     │  │   budget     │
    │              │  │              │  │              │
    │ • Prioritize │  │ • Search     │  │ • Generate   │
    │   by budget  │  │   activities │  │   extras     │
    │              │  │              │  │   (clothing, │
    │ • Consider   │  │ • Check      │  │    music)    │
    │   time       │  │   weather    │  │              │
    └──────────────┘  └──────────────┘  └──────────────┘
         ▲                   ▲                   ▲
         └───────────────────┴───────────────────┘
                    Context Sharing
```

---

## 🎨 UNIQUE FEATURES POWERED BY AI

```
┌─────────────────────────────────────────────────────────────┐
│                  NEMOTRON AI CAPABILITIES                    │
└─────────────────────────────────────────────────────────────┘

1. 👔 WEATHER-AWARE CLOTHING
   ┌──────────────────────────────────┐
   │ Input: NYC, November, 45°F, Rain │
   │         ↓                        │
   │  🧠 Nemotron Reasoning           │
   │         ↓                        │
   │ Output: Warm jacket, boots       │
   │         Navy/Gray palette        │
   └──────────────────────────────────┘

2. 🎵 LOCATION-BASED MUSIC
   ┌──────────────────────────────────┐
   │ Input: NYC, Urban, Fall vibes    │
   │         ↓                        │
   │  🧠 Nemotron Reasoning           │
   │         ↓                        │
   │ Output: "Empire State of Mind"   │
   │         Hip-hop, Indie rock      │
   └──────────────────────────────────┘

3. 💰 BUDGET OPTIMIZATION
   ┌──────────────────────────────────┐
   │ Input: $800 budget, 3 days       │
   │         ↓                        │
   │  🧠 Nemotron Reasoning           │
   │         ↓                        │
   │ Output: Balanced allocation      │
   │         Free activities if tight │
   └──────────────────────────────────┘
```

---

## 📱 USER JOURNEY

```
1. USER LANDS                2. FILLS FORM               3. SUBMITS
   on website                   with details                request
        │                           │                          │
        ▼                           ▼                          ▼
   ┌─────────┐               ┌─────────┐               ┌─────────┐
   │ Welcome │               │ Input   │               │ Loading │
   │  Page   │──────────────▶│  Form   │──────────────▶│ Spinner │
   └─────────┘               └─────────┘               └─────────┘
                                                             │
                                                             ▼
4. AI PROCESSES              5. GENERATES                6. USER SEES
   in background                complete plan              results in tabs
        │                           │                          │
        ▼                           ▼                          ▼
   ┌─────────┐               ┌─────────┐               ┌─────────┐
   │ Nemotron│               │Complete │               │ 6 Tabs  │
   │ Working │──────────────▶│Itinerary│──────────────▶│ of Info │
   └─────────┘               └─────────┘               └─────────┘
    (10-30 sec)                                          📅💰🗺️👔🎵📚
```

---

## 🔧 TECHNICAL STACK

```
┌──────────────────────────────────────────────────────────────┐
│                      FRONTEND                                 │
│  • HTML5, CSS3, JavaScript (ES6+)                            │
│  • Tailwind CSS (styling)                                    │
│  • Leaflet.js (maps)                                         │
│  • Fetch API (async requests)                                │
└────────────────────────┬─────────────────────────────────────┘
                         │ REST API (JSON)
┌────────────────────────▼─────────────────────────────────────┐
│                      BACKEND                                  │
│  • Python 3.9+                                               │
│  • Flask (web framework)                                     │
│  • Flask-CORS (cross-origin)                                 │
│  • Pydantic (data validation)                                │
└────────────────────────┬─────────────────────────────────────┘
                         │ API Calls
┌────────────────────────▼─────────────────────────────────────┐
│                     AI & APIS                                 │
│  • NVIDIA Nemotron LLM (reasoning)                           │
│  • Google Maps API (geocoding, distance)                     │
│  • Google Places API (hotels, POIs)                          │
│  • Google Gemini API (city history)                          │
│  • Weather API (climate data)                                │
└──────────────────────────────────────────────────────────────┘
```

---

## 🏆 WHAT MAKES US SPECIAL

```
┌────────────────────────────────────────────────────────────┐
│                  OTHER TRAVEL APPS                          │
│                                                             │
│  • Manual planning (time-consuming)                        │
│  • Fragmented across 5-10 apps                             │
│  • No AI reasoning                                          │
│  • Generic recommendations                                  │
│  • No style/music integration                               │
└────────────────────────────────────────────────────────────┘
                           VS
┌────────────────────────────────────────────────────────────┐
│                    NEMOCODE.IO                              │
│                                                             │
│  ✅ AI-powered (NVIDIA Nemotron)                            │
│  ✅ All-in-one platform                                     │
│  ✅ Agent-based reasoning                                   │
│  ✅ Weather-aware clothing suggestions                      │
│  ✅ Location-based music curation                           │
│  ✅ Budget optimization                                     │
│  ✅ City history integration                                │
│  ✅ Beautiful, modern UI                                    │
└────────────────────────────────────────────────────────────┘
```

---

## 💡 SLIDE DECK STRUCTURE RECOMMENDATION

### **Slide 1: Title**
- NemoCode.io
- "AI-Powered Travel Planning with NVIDIA Nemotron"

### **Slide 2: The Problem**
- Travel planning is fragmented
- 10 different apps for 1 trip
- Time-consuming, overwhelming

### **Slide 3: Our Solution**
- Show the ONE-SLIDE ARCHITECTURE
- Highlight "NVIDIA Nemotron AI Agent"

### **Slide 4: Agent Architecture**
- Show PLANNER → EXECUTOR → SYNTHESIZER
- Explain each component briefly

### **Slide 5: Unique Features**
- Weather-aware clothing
- Location-based music
- City history
- (Screenshots of each)

### **Slide 6: Live Demo**
- Actual demo or video walkthrough
- Show all 6 tabs

### **Slide 7: Technical Stack**
- Show the technical stack diagram
- Emphasize full-stack implementation

### **Slide 8: Impact & Future**
- Saves 5-10 hours per trip
- Democratizes travel planning
- Future: flights, restaurants, real-time updates

### **Slide 9: Thank You**
- Team names
- "Built with NVIDIA Nemotron at HackUTD"

---

## 🎨 COLOR SCHEME FOR SLIDES

Use your brand colors:
- **Primary**: #76B900 (your green)
- **Secondary**: #2C3E50 (dark blue-gray)
- **Accent**: #FFFFFF (white)
- **Text**: #333333 (dark gray)

---

**Copy these diagrams into your slides for maximum impact! 🚀**


